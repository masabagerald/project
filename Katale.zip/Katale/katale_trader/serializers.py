from rest_framework import serializers

from katale_trader.models import Product, Store, Contact, ProductImages


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = (
            "url", "id", "name", "type", "size", "source_location", "status", "price_per_unit", "store",
            "created")


class StoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Store
        fields = ("url", "id", "user", "name", "coordinates", "market", "market_location", "created")


class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImages
        fields = ("url", "id", "product", "image")


class ContactSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contact
        fields = ("url", "id", "user", "telephone")
