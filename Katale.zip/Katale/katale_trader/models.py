from django.contrib.auth.models import User
from django.db import models


class Store(models.Model):
    user = models.ForeignKey(User)
    name = models.CharField(max_length=20, default="none")
    coordinates = models.CharField(max_length=60, default="none")
    market = models.CharField(max_length=25)
    market_location = models.CharField(max_length=30)
    created = models.DateField(auto_now_add=True)

    class Meta:
        app_label = 'katale_trader'


class Product(models.Model):
    name = models.CharField(max_length=20)
    type = models.CharField(max_length=20)
    size = models.CharField(max_length=15)
    source_location = models.CharField(max_length=20)
    status = models.CharField(max_length=15)
    price_per_unit = models.CharField(max_length=20)
    store = models.ForeignKey(Store)
    created = models.DateField(auto_now_add=True)

    class Meta:
        app_label = 'katale_trader'


class ProductImages(models.Model):
    product = models.IntegerField()
    image = models.ImageField()


class Contact(models.Model):
    user = models.ForeignKey(User)
    telephone = models.IntegerField()

    class Meta:
        app_label = 'katale_trader'
