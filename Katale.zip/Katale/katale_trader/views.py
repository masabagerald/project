from rest_framework import viewsets

# Create your views here.
from katale_trader.models import Product, Store, Contact, ProductImages
from katale_trader.serializers import ProductSerializer, StoreSerializer, ContactSerializer, ProductImageSerializer


class ProductViewSet(viewsets.ModelViewSet):
    serializer_class = ProductSerializer
    queryset = Product.objects.all()

    def get_queryset(self):
        queryset = Product.objects.all()
        store = self.request.query_params.get('store', None)
        if store is not None:
            queryset = Product.objects.filter(store=store)
        return queryset


class StoreViewSet(viewsets.ModelViewSet):
    serializer_class = StoreSerializer
    queryset = Store.objects.all()

    def get_queryset(self):
        queryset = Store.objects.all()
        user = self.request.query_params.get('user', None)
        if user is not None:
            queryset = Store.objects.filter(user=user)
        return queryset


class ProductImageViewset(viewsets.ModelViewSet):
    serializer_class = ProductImageSerializer
    queryset = ProductImages.objects.all()

    def get_queryset(self):
        queryset = ProductImages.objects.all()
        product = self.request.query_params.get('product', None)
        if product is not None:
            queryset = ProductImages.objects.filter(product=product)
        return queryset


class ContactViewSet(viewsets.ModelViewSet):
    serializer_class = ContactSerializer
    queryset = Contact.objects.all()
