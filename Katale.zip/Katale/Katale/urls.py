"""Katale URL Configuration

"""
from django.conf.urls import include, url
from django.conf.urls.static import static
from django.contrib import admin
from rest_framework.routers import DefaultRouter

from Katale import settings
from katale_trader import views
from katale_trader.auth import auth_mobile_admin, register, check_username

router = DefaultRouter()

router.register(r'products', views.ProductViewSet)
router.register(r'stores', views.StoreViewSet)
router.register(r'contact', views.ContactViewSet)
router.register(r'product_images', views.ProductImageViewset)

urlpatterns = [
    url(r'^', include(router.urls)),
    url(r'^admin/', include(admin.site.urls)),
    url(r'^auth$', auth_mobile_admin, name='auth'),
    url(r'^register$', register, name='register'),
    url(r'^check_username', check_username, name='check_username'),
    url(r'vetDifferentials/', include('rest_framework.urls', namespace='rest_framework'))

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
