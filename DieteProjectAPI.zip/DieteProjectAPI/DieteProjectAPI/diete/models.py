from django.db import models

# Create your models here.
from django.utils import timezone
from pygments import highlight
from pygments.formatters.html import HtmlFormatter
from pygments.lexers.python import PythonLexer
from pygments.styles import get_all_styles
from diete import units


class Ingredients(models.Model):
    ingredient_name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.ingredient_name


class IngredientList(models.Model):
    """
    Ingredients are listed in order of use,
    if used at the same time list them in order of volume
    """
    list_title = models.CharField(max_length=35, default='', unique=True)
    list_of_all_ingredients = models.ManyToManyField(Ingredients, related_name="ingredients_all_related")
    list_of_most_important_ingredients = models.ManyToManyField(Ingredients,
                                                                related_name="ingredients_most_related")

    def __str__(self):
        return self.list_title


class IngredientQuantities(models.Model):
    ingredient_name = models.ForeignKey(Ingredients)
    ingredient_quantity = models.IntegerField(default=0)
    ingredient_quantity_unit = models.CharField(default='mg', max_length=10, choices=units.Units.UNITS)
    # referenced_ingredient_list = models.ForeignKey(IngredientList)

    def __str__(self):
        return '{0} : {1} {2}'.format(self.ingredient_name.ingredient_name, self.ingredient_quantity,
                                      self.ingredient_quantity_unit)


class Equipment(models.Model):
    name_of_equipment = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name_of_equipment


class EquipmentSize(models.Model):
    equipment_name = models.ForeignKey(Equipment)
    equipment_size = models.IntegerField(default=0)
    equipment_size_unit = models.CharField(default='gm', max_length=10, choices=units.Units.UNITS)

    def __str__(self):
        return '{0} : {1} {2}'.format(self.equipment_name.name_of_equipment, self.equipment_size,
                                      self.equipment_size_unit)


class EquipmentList(models.Model):
    list_name = models.CharField(max_length=50, unique=True)
    list_of_all_required_equipment = models.ManyToManyField(Equipment)

    def __str__(self):
        return self.list_name


class PreparationMethod(models.Model):
    preparation_method_name = models.CharField(max_length=50, unique=True)
    number_of_instructions = models.IntegerField(default=0)
    instructions = models.TextField(max_length=1000000)

    def __str__(self):
        return self.preparation_method_name


class RecipeManifest(models.Model):
    title = models.CharField(max_length=100, default='unknown', unique=True)
    number_of_servings = models.IntegerField(default=1)
    serving_size = models.IntegerField(default=1)
    ingredient_list = models.ManyToManyField(IngredientList, default=None)
    preparation_method = models.ForeignKey(PreparationMethod)
    equipment_required = models.ManyToManyField(EquipmentList)
    credits = models.TextField(max_length=100)
    list_of_elements = models.CharField(max_length=30)
    date_created = models.DateField(auto_now=False)
    date_last_modified = models.DateField(auto_now_add=True)
    owner = models.ForeignKey('auth.User', related_name='recipes_man')

    def __str__(self):
        return self.title

    class Meta:
        ordering = ('date_created',)


class RecipeList(models.Model):
    name_of_recipe = models.CharField(max_length=50, default="", unique=True)

    def __str__(self):
        return self.name_of_recipe


class Recipe(models.Model):
    title_of_recipe = models.ForeignKey(RecipeList)
    recipe_manifest = models.ForeignKey(RecipeManifest)
    ingredients = models.ManyToManyField(IngredientQuantities)
    equipment = models.ManyToManyField(EquipmentSize)
    owner = models.ForeignKey('auth.User', related_name='recipes', default=1)
    # manifest_highlight = models.TextField(default='')
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return self.title_of_recipe.name_of_recipe

    # def save(self, *args, **kwargs):
    #     # list = '{}'.format(self.recipe_manifest.ingredient_list.)
    #     code = '{}'.format(self.recipe_manifest.title)
    #     # self.manifest_highlight = '{}'.format(self.recipe_manifest.title)
    #     self.manifest_highlight = highlight(code, PythonLexer(), HtmlFormatter())
    #     super(Recipe, self).save(*args, **kwargs)
