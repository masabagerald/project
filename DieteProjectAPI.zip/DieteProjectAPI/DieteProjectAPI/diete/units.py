__author__ = 'wilson'


class Units:
    UNITS = (('default', 'no units'), ('kilogram', 'kg'), ('grams', 'gm'), ('liters', 'l'),)
