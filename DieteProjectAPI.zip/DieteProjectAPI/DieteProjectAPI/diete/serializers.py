from django.contrib.auth.models import User
from rest_framework import serializers
from diete.models import *

__author__ = 'wilson'


class RecipeManifestSerializer(serializers.HyperlinkedModelSerializer):
    owner = serializers.ReadOnlyField(source='owner.username')

    class Meta:
        model = RecipeManifest
        fields = ('id', 'title', 'number_of_servings', 'serving_size', 'ingredient_list',
                  'preparation_method', 'equipment_required', 'list_of_elements', 'credits',
                  'date_created', 'date_last_modified', 'owner')


class IngredientListSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = IngredientList
        fields = ('id', 'list_title', 'list_of_all_ingredients', 'list_of_most_important_ingredients',)


class IngredientsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ingredients
        fields = ('id', 'ingredient_name')


class IngredientQuantitiesSerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredientQuantities
        fields = ('id', 'ingredient_name', 'ingredient_quantity', 'ingredient_quantity_unit')


class EquipmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Equipment
        fields = ('id', 'name_of_equipment')


class EquipmentListSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = EquipmentList
        fields = ('id', 'list_name', 'list_of_all_required_equipment')


class EquipmentSizeSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentSize
        fields = ('id', 'equipment_name', 'equipment_size', 'equipment_size_unit')


class PreparationMethodSerializer(serializers.ModelSerializer):
    class Meta:
        model = PreparationMethod
        fields = ('id', 'preparation_method_name', 'number_of_instructions', 'instructions')


class RecipeListSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecipeList
        fields = ('id', 'name_of_recipe')


class RecipeSerializer(serializers.HyperlinkedModelSerializer):
    owner = serializers.ReadOnlyField(source='owner.username')
    # manifest_highlight = serializers.HyperlinkedIdentityField(view_name='recipe-manifest', format='html')
    title_of_recipe = serializers.CharField(default='', max_length=15)
    # recipe_manifest = serializers.CharField(default='', max_length=20)

    class Meta:
        model = Recipe
        fields = (
            'url', 'title_of_recipe', 'recipe_manifest', 'ingredients', 'equipment', 'owner',
            'is_deleted')


class UserSerializer(serializers.ModelSerializer):
    recipes = serializers.HyperlinkedRelatedField(many=True, queryset=RecipeManifest.objects.all(),
                                                  view_name='recipe-detail')

    class Meta:
        model = User
        fields = ('id', 'username', 'recipes')
