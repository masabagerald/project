from django.contrib.auth.models import User
from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets, permissions
from diete.serializers import *


class RecipeViewSet(viewsets.ModelViewSet):
    queryset = Recipe.objects.all()
    serializer_class = RecipeSerializer

    permission_classes = (permissions.IsAuthenticatedOrReadOnly,)

    # @detail_route(renderer_classes=[renderers.StaticHTMLRenderer])
    # def manifest(self, request, *args, **kwargs):
    #     recipe = self.get_object()
    #     return Response(recipe.manifest_highlight)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)



class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer


class IngredientListViewSet(viewsets.ModelViewSet):
    queryset = IngredientList.objects.all()
    serializer_class = IngredientListSerializer


class IngredientViewSet(viewsets.ModelViewSet):
    queryset = Ingredients.objects.all()
    serializer_class = IngredientsSerializer


class IngredientQuantityViewSet(viewsets.ModelViewSet):
    queryset = IngredientQuantities.objects.all()
    serializer_class = IngredientQuantitiesSerializer


class EquipmentViewSet(viewsets.ModelViewSet):
    queryset = Equipment.objects.all()
    serializer_class = EquipmentSerializer


class EquipmentListViewSet(viewsets.ModelViewSet):
    queryset = EquipmentList.objects.all()
    serializer_class = EquipmentListSerializer


class EquipmentSizeViewSet(viewsets.ModelViewSet):
    queryset = EquipmentSize.objects.all()
    serializer_class = EquipmentSizeSerializer


class PreparationMethodViewSet(viewsets.ModelViewSet):
    queryset = PreparationMethod.objects.all()
    serializer_class = PreparationMethodSerializer


class RecipeListViewSet(viewsets.ModelViewSet):
    queryset = RecipeList.objects.all()
    serializer_class = RecipeListSerializer

class RecipeManifestViewSet(viewsets.ModelViewSet):
    queryset = RecipeManifest.objects.all()
    serializer_class = RecipeManifestSerializer

    permission_classes = (permissions.IsAuthenticatedOrReadOnly,)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)
