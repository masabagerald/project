# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Equipment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name_of_equipment', models.CharField(unique=True, max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='EquipmentList',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('list_name', models.CharField(unique=True, max_length=50)),
                ('list_of_all_required_equipment', models.ManyToManyField(to='diete.Equipment')),
            ],
        ),
        migrations.CreateModel(
            name='EquipmentSize',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('equipment_size', models.IntegerField(default=0)),
                ('equipment_size_unit', models.CharField(default=b'gm', max_length=10, choices=[(b'default', b'no units'), (b'kilogram', b'kg'), (b'grams', b'gm'), (b'liters', b'l')])),
                ('equipment_name', models.ForeignKey(to='diete.Equipment')),
            ],
        ),
        migrations.CreateModel(
            name='IngredientList',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('list_title', models.CharField(default=b'', unique=True, max_length=35)),
            ],
        ),
        migrations.CreateModel(
            name='IngredientQuantities',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ingredient_quantity', models.IntegerField(default=0)),
                ('ingredient_quantity_unit', models.CharField(default=b'mg', max_length=10, choices=[(b'default', b'no units'), (b'kilogram', b'kg'), (b'grams', b'gm'), (b'liters', b'l')])),
            ],
        ),
        migrations.CreateModel(
            name='Ingredients',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ingredient_name', models.CharField(unique=True, max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='PreparationMethod',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('preparation_method_name', models.CharField(unique=True, max_length=50)),
                ('number_of_instructions', models.IntegerField(default=0)),
                ('instructions', models.TextField(max_length=1000000)),
            ],
        ),
        migrations.CreateModel(
            name='Recipe',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('is_deleted', models.BooleanField(default=False)),
                ('equipment', models.ManyToManyField(to='diete.EquipmentSize')),
                ('ingredients', models.ManyToManyField(to='diete.IngredientQuantities')),
                ('owner', models.ForeignKey(related_name='recipes', default=1, to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='RecipeList',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name_of_recipe', models.CharField(default=b'', unique=True, max_length=50)),
            ],
        ),
        migrations.CreateModel(
            name='RecipeManifest',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(default=b'unknown', unique=True, max_length=100)),
                ('number_of_servings', models.IntegerField(default=1)),
                ('serving_size', models.IntegerField(default=1)),
                ('credits', models.TextField(max_length=100)),
                ('list_of_elements', models.CharField(max_length=30)),
                ('date_created', models.DateField()),
                ('date_last_modified', models.DateField(auto_now_add=True)),
                ('equipment_required', models.ManyToManyField(to='diete.EquipmentList')),
                ('ingredient_list', models.ManyToManyField(default=None, to='diete.IngredientList')),
                ('owner', models.ForeignKey(related_name='recipes_man', to=settings.AUTH_USER_MODEL)),
                ('preparation_method', models.ForeignKey(to='diete.PreparationMethod')),
            ],
            options={
                'ordering': ('date_created',),
            },
        ),
        migrations.AddField(
            model_name='recipe',
            name='recipe_manifest',
            field=models.ForeignKey(to='diete.RecipeManifest'),
        ),
        migrations.AddField(
            model_name='recipe',
            name='title_of_recipe',
            field=models.ForeignKey(to='diete.RecipeList'),
        ),
        migrations.AddField(
            model_name='ingredientquantities',
            name='ingredient_name',
            field=models.ForeignKey(to='diete.Ingredients'),
        ),
        migrations.AddField(
            model_name='ingredientlist',
            name='list_of_all_ingredients',
            field=models.ManyToManyField(related_name='ingredients_all_related', to='diete.Ingredients'),
        ),
        migrations.AddField(
            model_name='ingredientlist',
            name='list_of_most_important_ingredients',
            field=models.ManyToManyField(related_name='ingredients_most_related', to='diete.Ingredients'),
        ),
    ]
