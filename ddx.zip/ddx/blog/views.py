import json
from django.contrib.auth import authenticate
from django.contrib.auth.models import User, Group
from django.db import connection
from django.http import HttpResponse, HttpResponseNotAllowed
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets, renderers, permissions, pagination
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from blog.models import Thread, Comment
from blog.serializers import ThreadSerializer, CommentSerializer
from django.shortcuts import get_object_or_404


class ThreadsViewSet(viewsets.ModelViewSet):
    queryset = Thread.objects.all()
    serializer_class = ThreadSerializer

    def get_queryset(self):
        queryset = Thread.objects.all()
        thread = self.request.query_params.get('thread_title', None)
        if thread is not None:
            queryset = Thread.objects.filter(title=thread.title)
        return queryset


class CommentsViewSet(viewsets.ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer


def thread_comments(request, thread_id):
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM blog_comment WHERE thread_id={} ORDER BY created DESC'.format(thread_id))
    threads = dictfetchall(cursor)
    response = HttpResponse(
        json.dumps(threads)
    )
    return response



def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
        ]


@csrf_exempt
def auth_mobile(request):
    if request.method == 'POST':
        request_body = json.loads(request.body)

        name = request_body["username"]
        pwd = request_body["password"]
        user = authenticate(username=name, password=pwd)

        if user is not None:
            if user.is_active:
                token, created = Token.objects.get_or_create(user=user)

                response = HttpResponse(
                    json.dumps({'status': True, 'msg': 'user authenticated', 'token': "Token %s" % token.key}),
                    content_type="application/json")

                response['X-Authorization'] = "Token %s" % token.key

                return response

            else:

                return HttpResponse(
                    json.dumps({'status': False, 'msg': 'user account is not active.', 'errorCode': 11404}), status=401)

        else:

            return HttpResponse(
                json.dumps({'status': False, 'msg': 'user account doesn\'t exist.', 'errorCode': 11401}), status=401)

    else:

        return HttpResponseNotAllowed(request.method + ' method is not allowed.')


@csrf_exempt
def auth_developer(request):
    if request.method == 'POST':
        request_body = json.loads(request.body)

        name = request_body["username"]
        pwd = request_body["password"]
        user = authenticate(username=name, password=pwd)

        if user is not None:
            if user.is_active:
                _user = get_object_or_404(User, username=name)
                developer = get_object_or_404(Group, name='developers')
                cursor = connection.cursor()
                cursor.execute(
                    'SELECT * FROM auth_user_groups WHERE user_id={} AND group_id={}'.format(_user.id, developer.id))
                is_developer = dictfetchall(cursor)
                if (len(is_developer)) > 0:
                    token, created = Token.objects.get_or_create(user=user)
                    response = HttpResponse(
                        json.dumps({'status': True, 'msg': 'user authenticated', 'token': "Token %s" % token.key}),
                        content_type="application/json")
                    response['X-Authorization'] = "Token %s" % token.key
                    return response
                else:
                    return HttpResponse(
                        json.dumps({'status': False, 'msg': 'user account is not active.', 'errorCode': 11404}),
                        status=401)
            else:
                return HttpResponse(
                    json.dumps({'status': False, 'msg': 'user account is not active.', 'errorCode': 11404}), status=401)
        else:
            return HttpResponse(
                json.dumps({'status': False, 'msg': 'user account doesn\'t exist.', 'errorCode': 11401}), status=401)
    else:
        return HttpResponseNotAllowed(request.method + ' method is not allowed.')
