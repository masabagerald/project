# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Comment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created', models.TextField(auto_created=True)),
                ('comment', models.TextField(default=b'')),
                ('owner', models.CharField(default=b'', max_length=25)),
            ],
        ),
        migrations.CreateModel(
            name='Thread',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(default=b'', unique=True, max_length=40)),
                ('description', models.TextField(default=b'none')),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('owner', models.CharField(default=b'unknown', max_length=25)),
            ],
            options={
                'ordering': ('-created',),
            },
        ),
        migrations.AddField(
            model_name='comment',
            name='thread',
            field=models.ForeignKey(to='blog.Thread'),
        ),
    ]
