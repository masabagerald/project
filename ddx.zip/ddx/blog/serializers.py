from blog.models import Thread, Comment
from django.contrib.auth.models import User
__author__ = 'spaces'
from rest_framework import serializers


class ThreadSerializer(serializers.ModelSerializer):

    # owner = serializers.ReadOnlyField(source='owner.username')

    class Meta:
        model = Thread
        fields = ('url', 'id', 'title', 'description', 'created', 'owner')


class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = ('url', 'id', 'comment', 'thread', 'owner')


class UserSerializer(serializers.ModelSerializer):
    # references = serializers.HyperlinkedRelatedField(many=True, queryset=Reference.objects.all(),
    #                                                 view_name='reference-highlight')
    class Meta:
        model = User
        fields = ('username',)
