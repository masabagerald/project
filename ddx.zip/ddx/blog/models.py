import datetime
from django.db import models


class Thread(models.Model):
    title = models.CharField(max_length=40, default='', null=False, unique=True)
    description = models.TextField(default="none")
    created = models.DateTimeField(auto_now_add=True)
    owner = models.CharField(max_length=25, default="unknown", null=False)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return self.title


class Comment(models.Model):
    comment = models.TextField(default='')
    thread = models.ForeignKey(Thread)
    created = models.TextField(auto_created=True)
    owner = models.CharField(max_length=25, default="", null=False)

    def save(self, *args, **kwargs):
        self.created = "{}".format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
        super(Comment, self).save(*args, **kwargs)

    def __str__(self):
        return self.comment
