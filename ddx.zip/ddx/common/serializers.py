from django.contrib.auth.models import User, Group
from common.models import TermsAndConditions, AboutUs

__author__ = 'spaces'
from rest_framework import serializers


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            'username', 'email', 'first_name', 'last_name', 'date_joined', 'is_staff', 'is_active', 'is_superuser',
            'groups')


class GroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = ('id', 'name',)


class TermsAndConditionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TermsAndConditions
        fields = (
            'url', 'registration', 'professional_conduct', 'data_collected', 'contributors',
        )

class AboutUsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AboutUs
        fields = (
            'url', 'ddx_developers', 'ddx_application', 'veterinary_differentials',
        )