from django.contrib.auth.models import User

__author__ = 'spaces'

from django.db import models


class TermsAndConditions(models.Model):
    registration = models.TextField()
    professional_conduct = models.TextField()
    data_collected = models.TextField()
    contributors = models.TextField()


class AboutUs(models.Model):
    ddx_developers = models.TextField()
    ddx_application = models.TextField()
    veterinary_differentials = models.TextField()
