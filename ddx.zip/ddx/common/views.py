import json
from tokenize import Token
from django.contrib.auth import authenticate
from django.contrib.auth.models import User, Group
from django.db import connection
from django.http import HttpResponse, HttpResponseNotAllowed
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from common.models import TermsAndConditions, AboutUs
from refs import permissions

from common.serializers import UserSerializer, GroupSerializer, TermsAndConditionsSerializer, AboutUsSerializer

__author__ = 'spaces'

from rest_framework import viewsets


class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def get_queryset(self):
        queryset = User.objects.all()
        user = self.request.query_params.get('username', None)
        if user is not None:
            queryset = User.objects.filter(username=user)
        return queryset


class GroupViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Group.objects.all()
    serializer_class = GroupSerializer

    def get_queryset(self):
        queryset = Group.objects.all()
        group = self.request.query_params.get('group', None)
        if group is not None:
            queryset = Group.objects.filter(name=group)
        return queryset


@csrf_exempt
def auth_mobile(request):
    if request.method == 'POST':
        request_body = json.loads(request.body)

        name = request_body["username"]
        pwd = request_body["password"]
        user = authenticate(username=name, password=pwd)

        if user is not None:
            if user.is_active:
                token, created = Token.objects.get_or_create(user=user)

                response = HttpResponse(
                    json.dumps({'status': True, 'msg': 'user authenticated', 'token': "Token %s" % token.key}),
                    content_type="application/json")

                response['X-Authorization'] = "Token %s" % token.key

                return response

            else:

                return HttpResponse(
                    json.dumps({'status': False, 'msg': 'user account is not active.', 'errorCode': 11404}), status=401)

        else:

            return HttpResponse(
                json.dumps({'status': False, 'msg': 'user account doesn\'t exist.', 'errorCode': 11401}), status=401)

    else:

        return HttpResponseNotAllowed(request.method + ' method is not allowed.')


def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
        ]


class TermsAndConditionsViewSet(viewsets.ModelViewSet):
    queryset = TermsAndConditions.objects.all()
    serializer_class = TermsAndConditionsSerializer
    permission_classes = (permissions.IsAllowAny,)


class AboutUsViewSet(viewsets.ModelViewSet):
    queryset = AboutUs.objects.all()
    serializer_class = AboutUsSerializer
    permission_classes = (permissions.IsAllowAny,)
