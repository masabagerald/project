# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='AboutUs',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ddx_developers', models.TextField()),
                ('ddx_application', models.TextField()),
                ('veterinary_differentials', models.TextField()),
            ],
        ),
        migrations.CreateModel(
            name='TermsAndConditions',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('registration', models.TextField()),
                ('professional_conduct', models.TextField()),
                ('data_collected', models.TextField()),
                ('contributors', models.TextField()),
            ],
        ),
    ]
