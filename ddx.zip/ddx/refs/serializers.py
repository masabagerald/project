from django.contrib.auth.models import User
from refs.models import Reference

__author__ = 'spaces'

from rest_framework import serializers


class ReferenceSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = Reference
        fields = ('url', 'description', 'owner', 'created',)


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'date_joined')
