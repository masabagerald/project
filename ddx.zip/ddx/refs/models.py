from django.db import models
from django.contrib.auth.models import User
from pygments import highlight
from pygments.formatters.html import HtmlFormatter
from pygments.lexers import get_all_lexers, get_lexer_by_name
from pygments.styles import get_all_styles
from django.contrib.auth.hashers import make_password


class Reference(models.Model):
    description = models.TextField()
    owner = models.CharField(max_length=15)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-created',)


