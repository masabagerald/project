from django.contrib.auth.models import User
from rest_framework import permissions

__author__ = 'wilson'


class IsAllowAny(permissions.AllowAny):
    """
    Custom permission to only allow all users.
    """