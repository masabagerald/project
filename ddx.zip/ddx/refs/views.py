from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.shortcuts import render
from rest_framework import viewsets, renderers, permissions
from rest_framework.decorators import detail_route
from rest_framework.response import Response
from refs.models import Reference
from refs.serializers import ReferenceSerializer, UserSerializer

'''
This view represents the viewset for the Reference model
of references app in ddx
'''


class ReferencesViewSet(viewsets.ModelViewSet):
    queryset = Reference.objects.all()
    serializer_class = ReferenceSerializer


class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
