from django.conf.urls import include, url
from django.contrib import admin
from rest_framework.routers import DefaultRouter
from refs import views as ref_views
from blog import views as blog_views
from common import views as common_views
from diagnosis import views as diagnosis_views

router = DefaultRouter()
router.register(r'references', ref_views.ReferencesViewSet)
router.register(r'threads', blog_views.ThreadsViewSet)
router.register(r'comments', blog_views.CommentsViewSet)
router.register(r'diseases', diagnosis_views.DiseasesViewSet)
router.register(r'epidemiology', diagnosis_views.EpidemiologyViewSet)
router.register(r'clinical', diagnosis_views.ClinicalFindingsViewSet)
router.register(r'pathology', diagnosis_views.PathologicalFindingsViewSet)
router.register(r'diagnosis', diagnosis_views.DiagnosisViewSet)
router.register(r'users', common_views.UserViewSet)
router.register(r'groups', common_views.GroupViewSet)
router.register(r'about', common_views.AboutUsViewSet)
router.register(r'terms', common_views.TermsAndConditionsViewSet)
router.register(r'pathognomonic_signs', diagnosis_views.PathognomonicSignViewSet)

urlpatterns = [
    url(r'^', include(router.urls)),
    url(r'^admin/', include(admin.site.urls)),
    url(r'^auth$', blog_views.auth_mobile, name='auth'),
    url(r'^developer$', blog_views.auth_developer, name='developer'),
    url(r'^comments/(?P<thread_id>[0-9]+)$', blog_views.thread_comments, name='thread_comments'),
    url(r'ddx/', include('rest_framework.urls', namespace='rest_framework'))
]
