from django.shortcuts import render
from rest_framework import viewsets, generics
from diagnosis.models import Diseases, Epidemiology, ClinicalFindings, PathologicalFindings, Diagnosis, \
    PathognomonicSign, EpidemiologyMap
from diagnosis.serializers import DiseasesSerializers, EpidemiologySerializers, ClinicalFindingsSerializers, \
    PathologicalFindingsSerializers, DiagnosisSerializers, PathognomonicSignSerializers, EpidemiologyMapSerializers
from rest_framework import permissions


class DiseasesViewSet(viewsets.ModelViewSet):
    queryset = Diseases.objects.all()
    serializer_class = DiseasesSerializers


class EpidemiologyViewSet(viewsets.ModelViewSet):
    queryset = Epidemiology.objects.all()
    serializer_class = EpidemiologySerializers


class ClinicalFindingsViewSet(viewsets.ModelViewSet):
    queryset = ClinicalFindings.objects.all()
    serializer_class = ClinicalFindingsSerializers


class PathologicalFindingsViewSet(viewsets.ModelViewSet):
    queryset = PathologicalFindings.objects.all()
    serializer_class = PathologicalFindingsSerializers


class DiagnosisViewSet(viewsets.ModelViewSet):
    serializer_class = DiagnosisSerializers
    queryset = Diagnosis.objects.all()

    def get_queryset(self):
        queryset = Diagnosis.objects.all()
        disease = self.request.query_params.get('disease_id', None)
        if disease is not None:
            queryset = Diagnosis.objects.filter(disease=disease)
        return queryset


class PathognomonicSignViewSet(viewsets.ModelViewSet):
    serializer_class = PathognomonicSignSerializers
    queryset = PathognomonicSign.objects.all()

    def get_queryset(self):
        queryset = PathognomonicSign.objects.all()
        sign = self.request.query_params.get('sign', None)
        if sign is not None:
            queryset = PathognomonicSign.objects.filter(signs__contains=sign)
        return queryset


class EpidemiologyMapViewSet(viewsets.ModelViewSet):
    serializer_class = EpidemiologyMapSerializers
    queryset = EpidemiologyMap.objects.all()

    def get_queryset(self):
        queryset = EpidemiologyMap.objects.all()
        sign = self.request.query_params.get('sign', None)
        if sign is not None:
            queryset = EpidemiologyMap.objects.filter(signs__contains=sign)
        return queryset
