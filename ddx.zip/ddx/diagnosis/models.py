from django.db import models


class Diseases(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    owner = models.CharField(max_length=15)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ('-created',)


class Epidemiology(models.Model):
    description = models.TextField()
    disease = models.ForeignKey(Diseases)
    created = models.DateTimeField(auto_now_add=True)
    owner = models.CharField(max_length=15)

    def __str__(self):
        return self.description

    class Meta:
        ordering = ('-created',)


class ClinicalFindings(models.Model):
    description = models.TextField()
    disease = models.ForeignKey(Diseases)
    created = models.DateTimeField(auto_now_add=True)
    owner = models.CharField(max_length=15)

    def __str__(self):
        return self.description

    class Meta:
        ordering = ('-created',)


class PathologicalFindings(models.Model):
    description = models.TextField()
    disease = models.ForeignKey(Diseases)
    created = models.DateTimeField(auto_now_add=True)
    owner = models.CharField(max_length=15)

    def __str__(self):
        return self.description

    class Meta:
        ordering = ('-created',)


class Diagnosis(models.Model):
    notes = models.TextField()
    disease = models.ForeignKey(Diseases)
    epidemiology = models.ForeignKey(Epidemiology)
    clinical_findings = models.ForeignKey(ClinicalFindings)
    pathological_findings = models.ForeignKey(PathologicalFindings)
    created = models.DateTimeField(auto_now_add=True)
    owner = models.CharField(max_length=15)

    class Meta:
        ordering = ('-created',)


class PathognomonicSign(models.Model):
    disease = models.ForeignKey(Diseases)
    signs = models.CharField(max_length=200, default="")
    construct = models.TextField(default="")
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-created',)


class EpidemiologyMap(models.Model):
    disease = models.ForeignKey(Diseases)
    signs = models.CharField(max_length=100, default="")
    construct = models.TextField()
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-created',)