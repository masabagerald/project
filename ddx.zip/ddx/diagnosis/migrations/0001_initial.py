# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='ClinicalFindings',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('description', models.TextField()),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('owner', models.CharField(max_length=15)),
            ],
            options={
                'ordering': ('-created',),
            },
        ),
        migrations.CreateModel(
            name='Diagnosis',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('notes', models.TextField()),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('owner', models.CharField(max_length=15)),
                ('clinical_findings', models.ForeignKey(to='diagnosis.ClinicalFindings')),
            ],
            options={
                'ordering': ('-created',),
            },
        ),
        migrations.CreateModel(
            name='Diseases',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=50)),
                ('description', models.TextField()),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('owner', models.CharField(max_length=15)),
            ],
            options={
                'ordering': ('-created',),
            },
        ),
        migrations.CreateModel(
            name='Epidemiology',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('description', models.TextField()),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('owner', models.CharField(max_length=15)),
                ('disease', models.ForeignKey(to='diagnosis.Diseases')),
            ],
            options={
                'ordering': ('-created',),
            },
        ),
        migrations.CreateModel(
            name='PathognomonicSign',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('signs', models.CharField(default=b'', max_length=200)),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('disease', models.ForeignKey(to='diagnosis.Diseases')),
            ],
        ),
        migrations.CreateModel(
            name='PathologicalFindings',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('description', models.TextField()),
                ('created', models.DateTimeField(auto_now_add=True)),
                ('owner', models.CharField(max_length=15)),
                ('disease', models.ForeignKey(to='diagnosis.Diseases')),
            ],
            options={
                'ordering': ('-created',),
            },
        ),
        migrations.AddField(
            model_name='diagnosis',
            name='disease',
            field=models.ForeignKey(to='diagnosis.Diseases'),
        ),
        migrations.AddField(
            model_name='diagnosis',
            name='epidemiology',
            field=models.ForeignKey(to='diagnosis.Epidemiology'),
        ),
        migrations.AddField(
            model_name='diagnosis',
            name='pathological_findings',
            field=models.ForeignKey(to='diagnosis.PathologicalFindings'),
        ),
        migrations.AddField(
            model_name='clinicalfindings',
            name='disease',
            field=models.ForeignKey(to='diagnosis.Diseases'),
        ),
    ]
