from diagnosis.models import Diseases, Epidemiology, ClinicalFindings, PathologicalFindings, Diagnosis, PathognomonicSign, \
    EpidemiologyMap

__author__ = 'wilson'

from rest_framework import serializers


class DiseasesSerializers(serializers.ModelSerializer):
    class Meta:
        model = Diseases
        fields = ('id', 'name', 'description', 'created', 'owner')


class EpidemiologySerializers(serializers.ModelSerializer):
    class Meta:
        model = Epidemiology
        fields = ('id', 'description', 'disease', 'created', 'owner')


class ClinicalFindingsSerializers(serializers.ModelSerializer):
    class Meta:
        model = ClinicalFindings
        fields = ('id', 'description', 'disease', 'created', 'owner')


class PathologicalFindingsSerializers(serializers.ModelSerializer):
    class Meta:
        model = PathologicalFindings
        fields = ('id', 'description', 'disease', 'created', 'owner')


class DiagnosisSerializers(serializers.ModelSerializer):
    class Meta:
        model = Diagnosis
        fields = (
            'id', 'notes', 'disease', 'epidemiology', 'clinical_findings', 'pathological_findings', 'created', 'owner')


class PathognomonicSignSerializers(serializers.ModelSerializer):
    class Meta:
        model = PathognomonicSign
        fields = (
            'url', 'id', 'disease', 'signs'
        )


class EpidemiologyMapSerializers(serializers.ModelSerializer):
    class Meta:
        model = EpidemiologyMap
        fields = (
            'url', 'id', 'disease', 'signs', 'construct'
        )
